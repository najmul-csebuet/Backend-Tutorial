package com.example.mavenjibdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenjibdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MavenjibdemoApplication.class, args);
	}

}
