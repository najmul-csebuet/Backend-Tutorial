package com.example.ProducerListObjFromJson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerListObjFromJsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
