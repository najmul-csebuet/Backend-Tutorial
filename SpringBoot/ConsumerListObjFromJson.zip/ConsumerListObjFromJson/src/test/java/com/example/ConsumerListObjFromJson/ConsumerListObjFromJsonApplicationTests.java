package com.example.ConsumerListObjFromJson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerListObjFromJsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
