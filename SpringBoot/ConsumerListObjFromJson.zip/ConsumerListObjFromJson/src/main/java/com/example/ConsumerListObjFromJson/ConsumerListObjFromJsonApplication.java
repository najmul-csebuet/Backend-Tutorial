package com.example.ConsumerListObjFromJson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumerListObjFromJsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumerListObjFromJsonApplication.class, args);
	}

}
