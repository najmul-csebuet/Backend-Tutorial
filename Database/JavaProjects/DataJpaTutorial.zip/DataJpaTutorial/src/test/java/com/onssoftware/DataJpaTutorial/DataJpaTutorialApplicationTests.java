package com.onssoftware.DataJpaTutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataJpaTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
