package com.onssoftware.DataJpaTutorial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataJpaTutorialApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataJpaTutorialApplication.class, args);
	}

}
